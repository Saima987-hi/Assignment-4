# Assignment 4 – Application 8: App8_TodoWithDatabase

## How to Run

1. Open terminal in this folder
2. Run:
   ```
   dotnet restore
   dotnet run
   ```
3. Open browser at: https://localhost:5001 or http://localhost:5000

## Requirements
- .NET 8 SDK (https://dotnet.microsoft.com/download/dotnet/8.0)
